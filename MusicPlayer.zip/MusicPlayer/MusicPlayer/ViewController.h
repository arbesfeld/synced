//
//  ViewController.h
//  MusicPlayer
//
//  Created by Matthew Arbesfeld on 2/7/13.
//  Copyright (c) 2013 Matthew Arbesfeld. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
