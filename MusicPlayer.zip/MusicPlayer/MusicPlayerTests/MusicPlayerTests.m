//
//  MusicPlayerTests.m
//  MusicPlayerTests
//
//  Created by Matthew Arbesfeld on 2/7/13.
//  Copyright (c) 2013 Matthew Arbesfeld. All rights reserved.
//

#import "MusicPlayerTests.h"

@implementation MusicPlayerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in MusicPlayerTests");
}

@end
