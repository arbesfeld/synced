//
//  MusicPlayerTests.h
//  MusicPlayerTests
//
//  Created by Matthew Arbesfeld on 2/7/13.
//  Copyright (c) 2013 Matthew Arbesfeld. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MusicPlayerTests : SenTestCase

@end
